@echo off
setlocal
cd /d "%~dp0"
if not exist build mkdir build

where cl >nul 2>nul
if errorlevel 1 (
  echo ERROR: Visual C++ compiler (cl.exe) not found.
  echo Open "x64 Native Tools Command Prompt for VS" and run this file again.
  pause
  exit /b 1
)

rc /nologo /fo build\AvreFile.res resources\AvreFile.rc
if errorlevel 1 goto fail

cl /nologo /O1 /Os /MT /GL /Gw /Gy /DNDEBUG /DUNICODE /D_UNICODE /W3 /EHsc ^
  src\AvreFile.cpp build\AvreFile.res ^
  /link /LTCG /OPT:REF /OPT:ICF /SUBSYSTEM:WINDOWS /DYNAMICBASE /NXCOMPAT ^
  comctl32.lib shell32.lib shlwapi.lib /OUT:build\AvreFile.exe
if errorlevel 1 goto fail

if not exist "dist\Avre File Portable" mkdir "dist\Avre File Portable"
copy /y build\AvreFile.exe "dist\Avre File Portable\AvreFile.exe" >nul
copy /y resources\AvreFile.ico "dist\Avre File Portable\AvreFile.ico" >nul
copy /y AvreConfig.ini "dist\Avre File Portable\AvreConfig.ini" >nul
copy /y README.md "dist\Avre File Portable\LEEME.txt" >nul
powershell -NoProfile -Command "Compress-Archive -Path 'dist\Avre File Portable\*' -DestinationPath 'AvreFile-Portable-Windows-x64.zip' -Force"
if errorlevel 1 goto fail

echo.
echo SUCCESS: Customer-ready ZIP created:
echo AvreFile-Portable-Windows-x64.zip
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Check compiler/resource errors above.
pause
exit /b 1
