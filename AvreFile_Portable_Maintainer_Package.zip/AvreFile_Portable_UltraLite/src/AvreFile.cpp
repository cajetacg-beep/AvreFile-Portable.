// Avre File Portable - UltraLite Edition
// Native Win32 starter implementation for Windows 10/11 (x64).
// No third-party runtime, no background service, no bundled codecs.

#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define IDI_AVRE 101
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cwctype>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")

static HINSTANCE g_inst;
static HWND g_main, g_list, g_path, g_status, g_search;
static std::wstring g_current = L"C:\\";
static const int ID_PATH=101, ID_LIST=102, ID_UP=103, ID_REFRESH=104, ID_PREVIEW=105, ID_SEARCH=106, ID_MINIVIEW=107;
static const int ID_EDITOR=201, ID_SAVE=202, ID_EDITBOX=203;
static std::wstring g_editorFile;
static HWND g_editorWnd, g_editBox;
static bool g_editorDirty=false;\nstatic bool g_miniView=false;

static std::wstring lower(std::wstring s) {
    std::transform(s.begin(), s.end(), s.begin(), towlower);
    return s;
}
static bool isText(const std::wstring& p) {
    static const wchar_t* exts[] = {L".txt",L".log",L".ini",L".cfg",L".conf",L".csv",
        L".tsv",L".md",L".markdown",L".json",L".xml",L".html",L".htm",L".css",
        L".js",L".ts",L".py",L".c",L".cpp",L".h",L".hpp",L".bat",L".cmd",
        L".ps1",L".sql",L".yaml",L".yml",L".toml",L".rtf"};
    std::wstring e = lower(PathFindExtensionW(p.c_str()));
    for (auto x: exts) if (e == x) return true;
    return false;
}
static std::wstring fileSize(ULONGLONG n) {
    wchar_t b[64];
    if (n < 1024) swprintf_s(b,L"%llu B",n);
    else if (n < 1024ULL*1024) swprintf_s(b,L"%.1f KB",n/1024.0);
    else swprintf_s(b,L"%.1f MB",n/(1024.0*1024));
    return b;
}
static void status(const std::wstring& s) { SetWindowTextW(g_status,s.c_str()); }

static void fillList() {
    ListView_DeleteAllItems(g_list);
    WIN32_FIND_DATAW fd{};
    std::wstring pattern = g_current;
    if (!pattern.empty() && pattern.back()!=L'\\') pattern += L'\\';
    pattern += L"*";
    HANDLE h=FindFirstFileW(pattern.c_str(),&fd);
    int count=0;
    if (h!=INVALID_HANDLE_VALUE) {
        do {
            std::wstring name=fd.cFileName;
            if (name==L"." || name==L"..") continue;
            wchar_t queryBuf[512]{};
            if (g_search) GetWindowTextW(g_search, queryBuf, 512);
            std::wstring query = lower(queryBuf);
            if (!query.empty() && lower(name).find(query)==std::wstring::npos) continue;
            bool dir=(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)!=0;
            LVITEMW item{}; item.mask=LVIF_TEXT; item.iItem=count;
            item.pszText=(LPWSTR)name.c_str();
            int row=ListView_InsertItem(g_list,&item);
            std::wstring type=dir?L"File folder":PathFindExtensionW(name.c_str());
            if (type.empty() && !dir) type=L"File";
            ListView_SetItemText(g_list,row,1,(LPWSTR)type.c_str());
            ULONGLONG sz=((ULONGLONG)fd.nFileSizeHigh<<32)|fd.nFileSizeLow;
            std::wstring size=dir?L"":fileSize(sz);
            ListView_SetItemText(g_list,row,2,(LPWSTR)size.c_str());
            count++;
        } while (FindNextFileW(h,&fd));
        FindClose(h);
    }
    SetWindowTextW(g_path,g_current.c_str());
    status(std::to_wstring(count)+L" items  |  Avre File Portable UltraLite");
}
static void navigate(const std::wstring& p) {
    DWORD a=GetFileAttributesW(p.c_str());
    if (a==INVALID_FILE_ATTRIBUTES || !(a&FILE_ATTRIBUTE_DIRECTORY)) {
        status(L"Cannot open this folder.");
        return;
    }
    g_current=p;
    fillList();
}
static std::wstring selectedPath() {
    int i=ListView_GetNextItem(g_list,-1,LVNI_SELECTED);
    if (i<0) return L"";
    wchar_t name[1024]{};
    ListView_GetItemText(g_list,i,0,name,1024);
    std::wstring p=g_current;
    if (!p.empty() && p.back()!=L'\\') p+=L'\\';
    return p+name;
}
static bool readFile(const std::wstring& p, std::wstring& out) {
    HANDLE h=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
        nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if (h==INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz{};
    if (!GetFileSizeEx(h,&sz) || sz.QuadPart>4*1024*1024) { CloseHandle(h); return false; }
    DWORD bytes=(DWORD)sz.QuadPart;
    std::vector<char> data(bytes+2,0); DWORD got=0;
    bool ok=ReadFile(h,data.data(),bytes,&got,nullptr)!=0; CloseHandle(h);
    if (!ok) return false;
    if (got>=2 && (BYTE)data[0]==0xFF && (BYTE)data[1]==0xFE) {
        out.assign((wchar_t*)(data.data()+2),(got-2)/2);
    } else if (got>=2 && (BYTE)data[0]==0xFE && (BYTE)data[1]==0xFF) {
        out=L"[UTF-16 BE file: encoding conversion is not included in this ultra-lite build]";
    } else {
        int skip=(got>=3 && (BYTE)data[0]==0xEF && (BYTE)data[1]==0xBB && (BYTE)data[2]==0xBF)?3:0;
        int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,data.data()+skip,got-skip,nullptr,0);
        if (n>0) { out.resize(n); MultiByteToWideChar(CP_UTF8,0,data.data()+skip,got-skip,&out[0],n); }
        else {
            n=MultiByteToWideChar(CP_ACP,0,data.data()+skip,got-skip,nullptr,0);
            out.resize(n); if(n) MultiByteToWideChar(CP_ACP,0,data.data()+skip,got-skip,&out[0],n);
        }
    }
    return true;
}
static bool saveEditor() {
    int len=GetWindowTextLengthW(g_editBox);
    std::vector<wchar_t> buf((size_t)len+1);
    GetWindowTextW(g_editBox,buf.data(),len+1);
    HANDLE h=CreateFileW(g_editorFile.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,nullptr);
    if(h==INVALID_HANDLE_VALUE) return false;
    DWORD written=0;
    // Save as UTF-16 LE with BOM for predictable Unicode round-tripping.
    WORD bom=0xFEFF;
    bool ok=WriteFile(h,&bom,2,&written,nullptr)!=0;
    if(ok && len) ok=WriteFile(h,buf.data(),len*2,&written,nullptr)!=0;
    CloseHandle(h); g_editorDirty=false; return ok;
}
static LRESULT CALLBACK EditorProc(HWND w,UINT m,WPARAM wp,LPARAM lp) {
    switch(m) {
    case WM_CREATE: {
        CreateWindowW(L"BUTTON",L"Save",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,8,8,76,26,w,(HMENU)ID_SAVE,g_inst,nullptr);
        g_editBox=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|
            WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL,
            8,42,700,440,w,(HMENU)ID_EDITBOX,g_inst,nullptr);
        SendMessageW(g_editBox,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);
        std::wstring content;
        if(readFile(g_editorFile,content)) SetWindowTextW(g_editBox,content.c_str());
        else SetWindowTextW(g_editBox,L"Unable to read file. Files larger than 4 MB are not opened in the built-in editor.");
        return 0;
    }
    case WM_SIZE:
        MoveWindow(GetDlgItem(w,ID_SAVE),8,8,76,26,TRUE);
        MoveWindow(g_editBox,8,42,LOWORD(lp)-16,HIWORD(lp)-50,TRUE); return 0;
    case WM_COMMAND:
        if(LOWORD(wp)==ID_SAVE) {
            if(saveEditor()) MessageBoxW(w,L"File saved.",L"Avre File",MB_OK|MB_ICONINFORMATION);
            else MessageBoxW(w,L"Could not save this file.",L"Avre File",MB_OK|MB_ICONERROR);
        } else if(HIWORD(wp)==EN_CHANGE) g_editorDirty=true;
        return 0;
    case WM_CLOSE:
        if(g_editorDirty && MessageBoxW(w,L"Discard unsaved changes?",L"Avre File",MB_YESNO|MB_ICONQUESTION)!=IDYES) return 0;
        DestroyWindow(w); return 0;
    case WM_DESTROY: g_editorWnd=nullptr; return 0;
    }
    return DefWindowProcW(w,m,wp,lp);
}
static void openEditor(const std::wstring& p) {
    if(g_editorWnd) { SetForegroundWindow(g_editorWnd); return; }
    g_editorFile=p;
    g_editorWnd=CreateWindowExW(WS_EX_APPWINDOW,L"AvreEditorWindow",p.c_str(),
        WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,760,540,
        g_main,nullptr,g_inst,nullptr);
}
static void openSelected(bool preview=false) {
    std::wstring p=selectedPath(); if(p.empty()) return;
    DWORD a=GetFileAttributesW(p.c_str());
    if(a!=INVALID_FILE_ATTRIBUTES && (a&FILE_ATTRIBUTE_DIRECTORY)) { navigate(p); return; }
    if(isText(p)) openEditor(p);
    else ShellExecuteW(g_main,L"open",p.c_str(),nullptr,nullptr,SW_SHOWNORMAL);
}
static LRESULT CALLBACK MainProc(HWND w,UINT m,WPARAM wp,LPARAM lp) {
    switch(m) {
    case WM_CREATE: {
        INITCOMMONCONTROLSEX ic{sizeof(ic),ICC_LISTVIEW_CLASSES}; InitCommonControlsEx(&ic);
        CreateWindowW(L"BUTTON",L"Up",WS_CHILD|WS_VISIBLE,8,8,48,26,w,(HMENU)ID_UP,g_inst,nullptr);
        CreateWindowW(L"BUTTON",L"Refresh",WS_CHILD|WS_VISIBLE,60,8,66,26,w,(HMENU)ID_REFRESH,g_inst,nullptr);
        CreateWindowW(L"BUTTON",L"Quick Peek",WS_CHILD|WS_VISIBLE,130,8,82,26,w,(HMENU)ID_PREVIEW,g_inst,nullptr);
        CreateWindowW(L"BUTTON",L"MiniView",WS_CHILD|WS_VISIBLE,216,8,72,26,w,(HMENU)ID_MINIVIEW,g_inst,nullptr);
        g_path=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",g_current.c_str(),WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,
            294,8,270,26,w,(HMENU)ID_PATH,g_inst,nullptr);
        g_search=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,
            570,8,208,26,w,(HMENU)ID_SEARCH,g_inst,nullptr);
        SendMessageW(g_search,EM_SETCUEBANNER,TRUE,(LPARAM)L"Avre SmartSearch...");
        g_list=CreateWindowExW(WS_EX_CLIENTEDGE,WC_LISTVIEWW,L"",WS_CHILD|WS_VISIBLE|LVS_REPORT|LVS_SINGLESEL|LVS_SHOWSELALWAYS,
            8,42,770,440,w,(HMENU)ID_LIST,g_inst,nullptr);
        ListView_SetExtendedListViewStyle(g_list,LVS_EX_FULLROWSELECT|LVS_EX_DOUBLEBUFFER);
        LVCOLUMNW c{}; c.mask=LVCF_TEXT|LVCF_WIDTH;
        c.pszText=(LPWSTR)L"Name"; c.cx=440; ListView_InsertColumn(g_list,0,&c);
        c.pszText=(LPWSTR)L"Type"; c.cx=180; ListView_InsertColumn(g_list,1,&c);
        c.pszText=(LPWSTR)L"Size"; c.cx=120; ListView_InsertColumn(g_list,2,&c);
        g_status=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_LEFT,8,488,770,22,w,nullptr,g_inst,nullptr);
        fillList(); return 0;
    }
    case WM_SIZE:
        int width=LOWORD(lp);
        MoveWindow(g_path,294,8,(width>600?width-514:90),26,TRUE);
        MoveWindow(g_search,(width>600?width-230:width-16),8,(width>600?222:0),26,TRUE);
        MoveWindow(g_list,8,42,width-16,HIWORD(lp)-76,TRUE);
        MoveWindow(g_status,8,HIWORD(lp)-26,LOWORD(lp)-16,20,TRUE); return 0;
    case WM_COMMAND:
        if(LOWORD(wp)==ID_UP) {
            std::wstring p=g_current; if(p.size()>3) { PathRemoveBackslashW(&p[0]); PathRemoveFileSpecW(&p[0]); navigate(p); }
        } else if(LOWORD(wp)==ID_REFRESH) fillList();
        else if(LOWORD(wp)==ID_PREVIEW) openSelected(true);
        else if(LOWORD(wp)==ID_MINIVIEW) {
            g_miniView=!g_miniView;
            ListView_SetView(g_list,g_miniView?LV_VIEW_LIST:LV_VIEW_DETAILS);
            SetWindowTextW(GetDlgItem(w,ID_MINIVIEW),g_miniView?L"Details":L"MiniView");
        } else if(LOWORD(wp)==ID_SEARCH && HIWORD(wp)==EN_CHANGE) fillList();
        else if(LOWORD(wp)==ID_PATH && HIWORD(wp)==EN_KILLFOCUS) {
            wchar_t b[2048]; GetWindowTextW(g_path,b,2048); navigate(b);
        }
        return 0;
    case WM_NOTIFY:
        if(((LPNMHDR)lp)->idFrom==ID_LIST && ((LPNMHDR)lp)->code==NM_DBLCLK) openSelected();
        return 0;
    case WM_KEYDOWN:
        if(wp==VK_F5) fillList(); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(w,m,wp,lp);
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,LPWSTR,int show) {
    g_inst=h;
    WNDCLASSW ec{}; ec.lpfnWndProc=EditorProc; ec.hInstance=h; ec.lpszClassName=L"AvreEditorWindow";
    ec.hCursor=LoadCursor(nullptr,IDC_IBEAM); ec.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
    RegisterClassW(&ec);
    WNDCLASSW wc{}; wc.lpfnWndProc=MainProc; wc.hInstance=h; wc.lpszClassName=L"AvreMainWindow";
    wc.hCursor=LoadCursor(nullptr,IDC_ARROW); wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);
    wc.hIcon=(HICON)LoadImageW(h,MAKEINTRESOURCEW(IDI_AVRE),IMAGE_ICON,0,0,LR_DEFAULTSIZE); RegisterClassW(&wc);
    g_main=CreateWindowExW(0,L"AvreMainWindow",L"Avre File Portable - UltraLite",
        WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,800,560,nullptr,nullptr,h,nullptr);
    ShowWindow(g_main,show); UpdateWindow(g_main);
    MSG msg; while(GetMessageW(&msg,nullptr,0,0)>0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    return (int)msg.wParam;
}
