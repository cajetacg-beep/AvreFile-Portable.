# Avre File Portable — UltraLite Edition

**Target:** Windows 10 and Windows 11, x64  
**End-user experience:** download one ZIP, extract it to USB or any folder, run `AvreFile.exe`. No installer.

## For the person using Avre File
The final release ZIP is intended to contain:
- `AvreFile.exe` — the application
- `AvreFile.ico` — application icon
- `AvreConfig.ini` — portable settings
- `LEEME.txt` — short instructions

The user does **not** need Visual Studio, a compiler, or internet access to run a built release.

## For the developer / maintainer: generate the ready-to-use ZIP
This workspace does not contain a compiled Windows EXE. Build it once using either:

### Recommended: GitHub Actions (builds on a Windows machine in the cloud)
1. Create a GitHub repository and upload this project.
2. Open the repository's **Actions** tab.
3. Select **Build Avre File Portable**.
4. Press **Run workflow**.
5. Download the artifact named `AvreFile-Portable-Windows-x64`.

That artifact is the customer-facing ZIP: extract and run. The customer does not compile anything.

Pushing a tag such as `v0.1.0` also triggers the build.

### Local build
Install Visual Studio Build Tools with **Desktop development with C++** and the Windows SDK.
Open **x64 Native Tools Command Prompt for VS** in this folder and run `Compilar.bat`.

## Current prototype features
- Native Win32 folder explorer and details view.
- Folder navigation, path bar, refresh (F5), double-click open.
- Avre SmartSearch: filters the current folder as you type.
- Avre MiniView: compact list view toggle.
- Avre QuickPeek: opens supported text files in the built-in editor.
- Built-in text editor with UTF-16 LE saving.
- Audio/video files launch through the Windows default player.
- Custom multi-size Avre folder icon and Windows manifest.

## Performance and compatibility notes
- No Electron, Java, bundled browser, background service, or third-party runtime.
- The target is low idle memory use; **40 MB is not yet benchmarked or guaranteed**.
- The application is x64 and targets Windows 10/11. It will not run on 32-bit Windows.
- Playback support depends on the codecs and default media player installed in Windows.
- The editor limits files to 4 MB to avoid memory spikes on low-RAM PCs.
- This is an early prototype, not yet a fully tested production release.
